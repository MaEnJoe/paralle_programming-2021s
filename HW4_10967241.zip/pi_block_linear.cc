#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <random>
#include <cmath>
int main(int argc, char **argv)
 {
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // --- DON'T TOUCH END ---

    int hits = 0;
    int tag = 0;
    MPI_Status status;

    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_real_distribution<float> uniRand(-1, 1);        

    // TODO: init MPI
    MPI_Comm_rank(MPI_COMM_WORLD,&world_rank);
    MPI_Comm_size(MPI_COMM_WORLD,&world_size);

    if (world_rank > 0)
    {
        // TODO: handle workers 
	for(int i = 0 ; i < tosses/world_size; i++)
	{
	    double x = uniRand(generator);
	    double y = uniRand(generator);	    	
	    if(hypot(x,y) < 1)
		    hits++;
	}
        MPI_Send(&hits,1,MPI_INT,0,tag,MPI_COMM_WORLD);
    }
    else if (world_rank == 0)
    {
        // TODO: master
	for(int i = 0 ; i < tosses/world_size; i++)
	{
	    double x = uniRand(generator);
	    double y = uniRand(generator);	    	
	    if(hypot(x,y) < 1)
		    hits++;
	}
	int tmp = 0;
	tmp += hits;
        for(int source = 1 ; source < world_size ; source++)
        {
            MPI_Recv(&hits,1,MPI_INT,source,tag,MPI_COMM_WORLD,&status);
	    tmp += hits;
        }
	double pi = 0.0;
	pi = tmp/((double)tosses)*4;
	printf("total hits = %d\n",tmp);
	printf("pi = %5.8f\n",pi);
    }

    if (world_rank == 0)
    {
        //  TODO: process PI result

        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }
    MPI_Finalize();
    return 0;
}
