#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <iostream>
#include <random>
#include <ctime>
#include <ratio>
#include <chrono>
#include <algorithm>
#include <vector>
#include <numeric>

unsigned monte(unsigned);

int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---

    MPI_Win win;

    // TODO: MPI init

    MPI_Comm_size(MPI_COMM_WORLD, &world_size);
    MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
    unsigned chunck = (unsigned) (tosses / (world_size));
    unsigned hits = 0;

    if (world_rank == 0)
    {
        // Master
       // Use MPI to allocate memory for the target window
       unsigned *sharedMem;
       MPI_Alloc_mem(2 * sizeof(unsigned), MPI_INFO_NULL, &sharedMem);

       for(int i = 0; i < 2; i++)
       {
            sharedMem[i] = 0;
       }
       bool busyWaiting = true;

        MPI_Win_create(sharedMem, 2 * sizeof(unsigned), sizeof(unsigned), MPI_INFO_NULL,MPI_COMM_WORLD, &win);

        hits = monte(tosses - (world_size-1) * chunck);
        while(busyWaiting)
        {
            MPI_Win_lock(MPI_LOCK_SHARED, 0, 0, win);
            if(sharedMem[0] >= (world_size - 1))
            {
                busyWaiting = false;
            }
            MPI_Win_unlock(0, win);
        }
        hits += sharedMem[1];

       MPI_Free_mem(sharedMem);

    }
    else
    {
        unsigned counter = 1;
        unsigned data1 = monte(chunck);
        
        MPI_Win_create(NULL, 0, 1, MPI_INFO_NULL, MPI_COMM_WORLD, &win);
        MPI_Win_lock(MPI_LOCK_EXCLUSIVE, 0, 0, win);
        MPI_Accumulate(&counter, 1, MPI_UNSIGNED, 0, 0, 1, MPI_UNSIGNED,  MPI_SUM, win);
        MPI_Accumulate(&data1, 1, MPI_UNSIGNED, 0, 1, 1, MPI_UNSIGNED,  MPI_SUM, win);
        MPI_Win_unlock(0, win);
    }

    MPI_Win_free(&win);

    if (world_rank == 0)
    {
        // TODO: handle PI result
        pi_result = 4.0*hits/tosses;
        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }
    
    MPI_Finalize();
    return 0;
}

unsigned monte(unsigned tosses)
{
    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_real_distribution<float> uniRand(-1, 1);       
    double x = 0.0;
    double y = 0.0;
    unsigned hits = 0;
    for(int i = 0 ; i != tosses ;i++)
    {        
	    double x = uniRand(generator);
	    double y = uniRand(generator);	    	
	    if(hypot(x,y) < 1)
		    hits++;
    }
    return hits;
}
