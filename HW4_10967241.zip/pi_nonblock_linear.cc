#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <random>

std::random_device rd;
std::mt19937 generator(rd());
std::uniform_real_distribution<float> uniRand(-1, 1);        



int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---
    // TODO: MPI init
    int hits = 0;
    int tag = 0;
    MPI_Comm_rank(MPI_COMM_WORLD,&world_rank);
    MPI_Comm_size(MPI_COMM_WORLD,&world_size);
    
	MPI_Request req,reqs[world_size-1];
	MPI_Status mStatus,status[world_size-1];
	int aaa[world_size];
    if(world_rank == 0)
    {
		for(int i = 0 ; i < tosses/world_size; i++)
		{
		    double x = uniRand(generator);
			double y = uniRand(generator);	    	
	   	    if(hypot(x,y) < 1)
		    	hits++;
		}
		int tmp = 0;
		tmp += hits;
		for(int source = 1 ; source != world_size ; source++)	
		{
			MPI_Irecv(&aaa[source],1,MPI_INT,source,tag,MPI_COMM_WORLD,&reqs[source]);
		}
		for(int i = 1 ; i != world_size ; i++)
			MPI_Wait(&reqs[i],&status[i]);
		//	MPI_Waitall(world_size-1,reqs,status);
		for(int i = 1 ; i != world_size ; i++)
			tmp += aaa[i];
        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
		pi_result = tmp/(double)tosses*4;
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }
    else if(world_rank > 0)
    {
		for(int i = 0 ; i < tosses/world_size; i++)
		{
		    double x = uniRand(generator);
			double y = uniRand(generator);	    	
	   	    if(hypot(x,y) < 1)
		    	hits++;
		}
		int tmp = 0;
		tmp += hits;
		MPI_Isend(&hits,1,MPI_INT,0,tag,MPI_COMM_WORLD,&req);
		MPI_Wait(&req,&mStatus);		
    }
    MPI_Finalize();
    return 0;
}
