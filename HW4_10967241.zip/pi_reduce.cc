#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <random>

unsigned monte(unsigned);

int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---
    int send = 0;
    int recv = 0;
    // TODO: MPI init
    MPI_Comm_rank(MPI_COMM_WORLD,&world_rank);
    MPI_Comm_size(MPI_COMM_WORLD,&world_size);
    
    // TODO: use MPI_Reduce
    send = monte(tosses/world_size);
    const int root = 0;
    MPI_Reduce(&send,&recv,1,MPI_INT,MPI_SUM,root,MPI_COMM_WORLD);
    if (world_rank == 0)
    {
        // TODO: PI result
        pi_result = recv/(double)tosses*4;
        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }

    MPI_Finalize();
    return 0;
}

unsigned monte(unsigned tosses)
{
    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_real_distribution<float> uniRand(-1, 1);       
    double x = 0.0;
    double y = 0.0;
    unsigned hits = 0;
    for(int i = 0 ; i != tosses ;i++)
    {        
	    double x = uniRand(generator);
	    double y = uniRand(generator);	    	
	    if(hypot(x,y) < 1)
		    hits++;
    }
    return hits;
}
