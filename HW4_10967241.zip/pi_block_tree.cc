#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>
#include <random>
#include <cmath>
#include <cassert>

int powOf2(int);
int main(int argc, char **argv)
{
    // --- DON'T TOUCH ---
    MPI_Init(&argc, &argv);
    double start_time = MPI_Wtime();
    double pi_result;
    long long int tosses = atoi(argv[1]);
    int world_rank, world_size;
    // ---
    MPI_Status status;    
    int tag = 0;
    
    std::random_device rd;
    std::mt19937 generator(rd());
    std::uniform_real_distribution<float> uniRand(-1, 1);        

    MPI_Comm_rank(MPI_COMM_WORLD,&world_rank);
    MPI_Comm_size(MPI_COMM_WORLD,&world_size);
    // TODO: MPI init

    // TODO: binary tree redunction
    int floor = 1;
    int hits = 0;
    if (world_rank == 0)
    {
        // TODO: PI result

	    for(int i = 0 ; i != tosses/world_size ; i++)
        {
	         double x = uniRand(generator);
	         double y = uniRand(generator);	    	
	         if(hypot(x,y) < 1)
		            hits++;
        }
        int tmp = 0;
        tmp += hits;
        for(int i = 0; world_size/floor > 1 ; i++)//index i is unused
        {
            int source = floor;
            tag = floor;
	    printf("rank %d is recieving from %d (tag = %d )\n",world_rank,source,tag);
            MPI_Recv(&hits,1,MPI_INT,source,tag,MPI_COMM_WORLD,&status);
	    printf("\t\t---- %d<-%d complete!\n",world_rank,source);
            tmp += hits;
            floor *= 2;
        }
	    pi_result = tmp/(double)tosses*4;	
        // --- END OF STORY ---
        // --- DON'T TOUCH ---
        double end_time = MPI_Wtime();
        printf("%lf\n", pi_result);
        printf("MPI running time: %lf Seconds\n", end_time - start_time);
        // ---
    }
    else if(world_rank > 0)
    {        
	    for(int i = 0 ; i != tosses/world_size ; i++)
        {
            double x = uniRand(generator);
	        double y = uniRand(generator);	    	
	        if(hypot(x,y) < 1)
		    hits++;
        }
        int tmp = 0 ;
        tmp += hits ;
        while( (world_rank/floor) % 2 == 0 )//check if rank* is even (even is recieving)
        {
            int source = (world_rank/floor + 1)*floor;
            tag = floor;
	    printf("rank %d is recieving from %d (tag = %d)\n",world_rank,source,tag);
            MPI_Recv(&hits,1,MPI_INT,source,tag,MPI_COMM_WORLD,&status);
	    printf("\t\t---- %d<-%d complete!\n",world_rank,source);
            tmp += hits;
            floor *= 2;
        }
        //rank* is odd
        int dest = (world_rank/floor-1)*floor;
        tag = floor;
	//printf("rank %d is sending to %d (tag = %d)\n",world_rank,dest,tag);
        MPI_Send(&tmp,1,MPI_INT,dest,tag,MPI_COMM_WORLD);
	//printf("\t\t---- %d->%d complete!\n",world_rank,dest);

    }

    MPI_Finalize();
    return 0;
}
int powOf2(int pow)
{   
    assert(pow >= 0);
    int tmp = 1;
    for(int i = 0 ; i != pow ; i++)
    {
        tmp *= 2;
    }
    return tmp;
}
