#include <iostream>
#include <random>
#include <ctime>
#include <ratio>
#include <chrono>
#include <algorithm>
#include <mutex>
#include <numeric>
#include <functional>
#include <thread>

int TOSS_NUM = 1E9;
const size_t NNN = 1024;
typedef unsigned long long uint64;

using namespace std::chrono;

unsigned long long SIMDCarlo(const unsigned tossNum);
unsigned getHardwareThreadNum();

unsigned gThreadNum;
unsigned gHits = 0;
pthread_mutex_t gMutex;

void* dart(void* threadNum)
{
	uint64 tNum = (unsigned long long) threadNum;
	uint64 hits = 0;
	hits = SIMDCarlo(TOSS_NUM/(double)tNum);
	pthread_exit( (void*) hits) ;
	return NULL;
}


int main(int argc,char** argv)
{
	
	unsigned threadNum; 
	if(argc == 1)
	{
		threadNum = getHardwareThreadNum();
		TOSS_NUM = 1E9;
	}else
	{
		threadNum = atoi(argv[1]);
		TOSS_NUM = atoi(argv[2]);
	}
	// unsigned long long hits = 0; 

	//timer 
	// high_resolution_clock::time_point t1;
	// high_resolution_clock::time_point t2;
	// duration<double> time_span;

	pthread_t *thread_h = new pthread_t[threadNum];
	void** retval = new void*[threadNum];
	//thread creating 
	for(int i = 0 ; i != threadNum ; i++)
	{
		pthread_create(&thread_h[i],NULL,dart,(void*)threadNum);
	}
	//join
	for(int i = 0 ; i != threadNum ; i++)
	{
		pthread_join(thread_h[i],&retval[i]);
	}
	unsigned long long sum = 0;
	for(int i = 0 ; i != threadNum ; i++)
	{
		sum += (uint64) retval[i];
	}
	//add up the left 
	sum += SIMDCarlo(TOSS_NUM-(int)(TOSS_NUM/(double)threadNum*threadNum));
	double pi = 4*sum/(double)TOSS_NUM;

	printf("%.8f\n",pi);

	delete thread_h;
	delete[] retval;

	return 0;
}	

unsigned getHardwareThreadNum()
{
	const unsigned hardwareConcurrency = std::thread::hardware_concurrency();
	const unsigned threadNum = (hardwareConcurrency != 0) ? hardwareConcurrency : 1;
	return threadNum;
}

unsigned long long SIMDCarlo(const unsigned tossNum)
{
	std::random_device rd;
	std::mt19937 generator(rd());
	std::uniform_real_distribution<float> uniRand(-1, 1);
	unsigned long long hits = 0;
 
	float *__restrict x;
	float *__restrict y;
	x = new (std::align_val_t{ 32 }) float[NNN];
	y = new (std::align_val_t{ 32 }) float[NNN];
	x = (float* ) __builtin_assume_aligned(x,32);
	y = (float* ) __builtin_assume_aligned(y,32);

	for(int j = 0; j < tossNum/NNN; j++)
	{
		for(int i = 0; i < NNN; i++)
		{
			x[i] = uniRand(generator);
			y[i] = uniRand(generator);
		}
		for(int i = 0; i != NNN; i++)
		{
			x[i] = x[i]*x[i] +y[i]*y[i];
		}
		for(int i = 0; i != NNN; i++)
		{
			if( x[i]<= 1 )
				hits++;
		} 

	}
	delete x,y;

	return hits;
}
