#include <stdio.h>
#include <stdlib.h>
#include "hostFE.h"
#include "helper.h"

void hostFE(int filterWidth, float *filter, int imageHeight, int imageWidth,
            float *inputImage, float *outputImage, cl_device_id *device,
            cl_context *context, cl_program *program)
{
    cl_int status;
    int filterSizeByte = filterWidth * filterWidth * sizeof(float);
    int filterSize1 =  filterWidth * filterWidth;
    int memSizeByte = imageHeight * imageWidth * sizeof(float);
    int zeroSize = 0;
    //melloc an int array with length filtersize
    int *nonZeroEles = (int*)malloc(filterSize1 * sizeof(int));
    //record all index that's not zero
    int nonZeroIndex = 0, nonZeroSize = 0, nonZeroSize1 = 0;
    for(int i = 0; i < filterSize1; i++)
        {
            if(abs(filter[i] - 0) < 0.01) 
                zeroSize++;
            else{
                nonZeroEles[nonZeroIndex] = i;
                nonZeroIndex++;
            }         

        }
    nonZeroSize1 = nonZeroIndex;
    nonZeroSize = nonZeroSize1 * sizeof(int);
    //create command queue
    cl_command_queue myqueue;
    myqueue = clCreateCommandQueue(*context, *device, 0, &status);

    //allocate device memory
    cl_mem deviceFilter = clCreateBuffer(*context, CL_MEM_READ_ONLY, filterSizeByte, NULL, &status);
    cl_mem deviceInputImage = clCreateBuffer(*context, CL_MEM_READ_ONLY, memSizeByte, NULL, &status);
    cl_mem deviceOutputImage = clCreateBuffer(*context, CL_MEM_WRITE_ONLY, memSizeByte, NULL, &status);
    cl_mem deviceNonZeroIndexes = clCreateBuffer(*context, CL_MEM_READ_ONLY, nonZeroSize1 * sizeof(int), NULL, &status);

    // copy data from host memory to device memory
    status = clEnqueueWriteBuffer(myqueue, deviceFilter, CL_TRUE, 0, filterSizeByte, (void *)filter, 0, NULL, NULL);
    status = clEnqueueWriteBuffer(myqueue, deviceInputImage, CL_TRUE, 0, memSizeByte, (void *)inputImage, 0, NULL, NULL);

      status = clEnqueueWriteBuffer(myqueue, deviceNonZeroIndexes, CL_TRUE, 0, nonZeroSize1 * sizeof(int), (void *)nonZeroEles, 0, NULL, NULL);



    // create kernel function
    cl_kernel mykernel = clCreateKernel(*program, "convolution", status);

    // set kernel function args
    clSetKernelArg(mykernel, 0, sizeof(cl_int), (void *)&filterWidth);
    clSetKernelArg(mykernel, 1, sizeof(cl_mem), (void *)&deviceFilter);
    clSetKernelArg(mykernel, 2, sizeof(cl_int), (void *)&imageHeight);
    clSetKernelArg(mykernel, 3, sizeof(cl_int), (void *)&imageWidth);
    clSetKernelArg(mykernel, 4, sizeof(cl_mem), (void *)&deviceInputImage);
    clSetKernelArg(mykernel, 5, sizeof(cl_mem), (void *)&deviceOutputImage);
    clSetKernelArg(mykernel, 6, sizeof(cl_mem), (void *)&deviceNonZeroIndexes);
    clSetKernelArg(mykernel, 7, sizeof(cl_int), (void *)&nonZeroSize1);
    // assign workgroups parameter
    size_t localws[2] = {25, 25};
    size_t globalws[2] = {imageWidth, imageHeight};

    status = clEnqueueNDRangeKernel(myqueue, mykernel, 2, 0, globalws, localws, 0, NULL, NULL);

    // copy data from device memory to host memory
    status = clEnqueueReadBuffer(myqueue, deviceOutputImage, CL_TRUE, 0, memSizeByte, (void *)outputImage, NULL, NULL, NULL);

    // release opencl object
    status = clReleaseCommandQueue(myqueue);
    status = clReleaseMemObject(deviceInputImage);
    status = clReleaseMemObject(deviceFilter);
    status = clReleaseMemObject(deviceOutputImage);
    status = clReleaseKernel(mykernel);
    //release memory
    free(nonZeroEles);
}